#Telegram bot token = 1925342805:AAG7j9hBzAd0olw74goOJhfH7dNlMrTm0_w


from libgen_api import LibgenSearch

s = LibgenSearch()
title = "basic and clinical pharmacology"
results = s.search_title(title)

for result in results:
    msg = str(result)
    new_msg = " "
    symbols_remove = ["'","{","}"]
    for x in msg:
        if x in symbols_remove:
            new_msg += ""
        elif x == ":":
            new_msg += "-"
        elif x == ",":
            new_msg += "\n"
        else:
            new_msg += x
            
    print(new_msg)
    print('\n\n\n')
